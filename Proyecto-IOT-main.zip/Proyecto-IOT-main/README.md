# Proyecto-IOT

Heroku SQLite3, FastAPI demo
Heroku SQLite3, FastAPI demo

gunicorn -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000 main:app